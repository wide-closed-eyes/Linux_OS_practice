#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>


typedef struct
{
  int flag;
  char symb;
} threads;

void * stream1(void * arg)
{
  threads *args = (threads*) arg;
  printf("\nПоток 1 начал работу...\n");
  while(args->flag == 0)
  {
    printf("%c", args->symb);
    sleep(1);
  }
  printf ("Поток 1 закончил работу.\n");
  pthread_exit((void*)1);
}

void * stream2(void * arg)
{
  threads *args = (threads*) arg;
  printf("\nПоток 2 начал работу...\n");
  while(args->flag == 0)
  {
    printf("%c", args->symb);
    sleep(1);
  }
  printf ("Поток 2 закончил работу.\n");
  pthread_exit((void*)2);
}

int main()
{ 
  printf ("Программа начала работу...\n");
  pthread_t id1;
  pthread_t id2;
  
  int *exit_code1;
  int *exit_code2;
  
  threads arg1;
  arg1.flag = 0;
  arg1.symb = '1';
  
  threads arg2;
  arg2.flag = 0;
  arg2.symb = '2';
  
  int err_code;
  
  err_code =  pthread_create(&id1, NULL, stream1, &arg1);
  if (err_code != 0)
  {
    printf ("function error: %s\n", strerror(err_code));
    return err_code;
  }
  
  err_code = pthread_create(&id2, NULL, stream2, &arg2);
  if (err_code != 0)
  {
    printf ("function error: %s\n", strerror(err_code));
    return err_code;
  }
  
  printf ("Программа ждёт нажатия клавиши...\n");
  getchar();
  printf ("\nКлавиша нажата.\n");
  
  arg1.flag = 1;
  arg2.flag = 1;
  
  err_code = pthread_join(id1, (void**)&exit_code1);
  if (err_code != 0)
  {
    printf ("function error: %s\n", strerror(err_code));
    return err_code;
  }
  
  err_code = pthread_join(id2, (void**)&exit_code2);
  if (err_code != 0)
  {
    printf ("function error: %s\n", strerror(err_code));
    return err_code;
  }
  
  printf ("Программа завершила работу.\n");
  return 0;
}
