#!/bin/bash

gcc -c lab1.c
gcc -o lab1 lab1.o -pthread
