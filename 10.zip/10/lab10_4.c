#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <unistd.h>
#include <fcntl.h>
#include <ev.h>

int flag = 0; 
int filedes[2];


ev_io stdin_watcher;
ev_io stdin_watcherW;
ev_timer timeout_watcher;
  
struct ev_loop *loop;

static void stdin_cb(struct ev_loop *loop, ev_io *w, int revents)
{
  printf("function started...\n");
  
  ev_io_stop(loop, w);
  ev_io_stop(loop, &stdin_watcherW);
  ev_timer_stop(loop, &timeout_watcher);
  ev_break(loop, EVBREAK_ALL);
  
  //ev_break(loop, EVBREAK_ALL);
  
  printf("function finished.\n");
}

static void stdout_cb(struct ev_loop *loop, ev_io *w, int revents)
{
  char const_str[100];
  const_str[0] = 1;
  if (read(filedes[0], const_str, 100) != -1)
      printf("Поток 2 считал значение: %s\n", const_str);
  else
    perror("Ошибка чтения данных");
}

static void timer_cb(struct ev_loop *loop, ev_timer *t, int revents)
{
  char *curr_dir;
  curr_dir = get_current_dir_name();
  if (write(filedes[1], curr_dir, 100) != -1)
      printf("\nПоток 1 закончил запись\n");
  else
    perror("Ошибка в записи данных\n");
}

int main()
{
  printf("lab10_4 started...\n");
  
  char key;
  printf("Введине ключевое значение:\n1 - pipe2 без блокировки |Только для Linux|\n2 - pipe без блокировки\n");
  key = getchar();
  switch (key)
  {
  case '1':
  {
    if (pipe2(filedes, O_NONBLOCK) != 0)
    {
    perror("Ошибка в создании потока!");
    exit(EXIT_FAILURE);
    }
    break;
  }
  case '2':
  {
    if (pipe(filedes) == -1)
    {
    printf("ERROR");
    return -1;
    }
    fcntl(filedes[0], F_SETFL, O_NONBLOCK);
    fcntl(filedes[1], F_SETFL, O_NONBLOCK);
    break;
  }
  default:
  {
    printf("Введено некорректное ключевое значение\n");
    return -1;
  }
  }
  getchar();
  
  struct ev_loop *loop = ev_default_loop(EVFLAG_AUTO);
  
  ev_io_init(&stdin_watcher, stdin_cb, 0, EV_READ); //STDIN_FILENO = 0
  
  ev_timer_init(&timeout_watcher, timer_cb, 0, 1);
  ev_io_init(&stdin_watcherW, stdout_cb, filedes[0], EV_READ); //pipe files's descriptor = filedes[0]
  
  ev_io_start(loop, &stdin_watcher);
  
  ev_timer_start(loop, &timeout_watcher);
  ev_io_start(loop, &stdin_watcherW);
  
  printf("press <ENTER> to continue...\n");
  ev_run(loop, 0);
  
  close(filedes[0]);
  close(filedes[1]);
  
  printf("lab10_4 finished.\n");
  return 0;
}
