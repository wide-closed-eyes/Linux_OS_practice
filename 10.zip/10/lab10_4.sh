#!/bin/bash

gcc -c lab10_4.c
gcc -o lab10_4 lab10_4.o -lev

