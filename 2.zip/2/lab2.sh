#!/bin/bash

gcc -c lab2.c
gcc -o lab2 lab2.o -pthread
./lab2
