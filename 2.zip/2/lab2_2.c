#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>

pthread_mutex_t mutex;

typedef struct
{
  int flag;
  char symb;
} threads;

void * stream1(void * arg)
{
  struct timespec current_time;
  
  threads *args = (threads*) arg;
  printf("Поток 1 начал работу...\n");
  sleep(1);
  while(args->flag == 0)
  {
    while (pthread_mutex_trylock(&mutex) != 0)
    {
      clock_gettime (CLOCK_REALTIME, &current_time);
      printf("\nВремя до sleep:%ld\n", current_time.tv_nsec);
      sleep(0.25);
      clock_gettime (CLOCK_REALTIME, &current_time);
      printf("Время после sleep:%ld\n", current_time.tv_nsec);
    }
    for (int i = 0; i<5; i++)  
      printf("%c", args->symb);
    fflush(stdout);
    pthread_mutex_unlock(&mutex);
    sleep(1);
  }
  printf ("Поток 1 закончил работу.\n");
  pthread_exit((void*)1);
}

void * stream2(void * arg)
{
  struct timespec current_time;

  threads *args = (threads*) arg;
  printf("Поток 2 начал работу...\n");
  sleep(1);
  while(args->flag == 0)
  {
    while (pthread_mutex_trylock(&mutex) != 0)
    {
      clock_gettime (CLOCK_REALTIME, &current_time);
      printf("\nВремя до sleep:%ld\n", current_time.tv_nsec);
      sleep(0.25);
      clock_gettime (CLOCK_REALTIME, &current_time);
      printf("Время после sleep:%ld\n", current_time.tv_nsec);
    }
    for (int i = 0; i<5; i++)
      printf("%c", args->symb);
    fflush(stdout);
    pthread_mutex_unlock(&mutex);
    sleep(1);
  }
  printf ("Поток 2 закончил работу.\n");
  pthread_exit((void*)2);
}

int main()
{ 
  printf ("Программа начала работу...\n");
  pthread_t id1;
  pthread_t id2;
  
  int *exit_code1;
  int *exit_code2;
  
  threads arg1;
  arg1.flag = 0;
  arg1.symb = '1';
  
  threads arg2;
  arg2.flag = 0;
  arg2.symb = '2';
  
  int err_code1, err_code2;
  
  err_code1 = pthread_mutex_init(&mutex, NULL);
  if (err_code1 != 0)
  {
    printf ("function error: %s\n", strerror(err_code1));
    return err_code1;
  }
  
  err_code1 =  pthread_create(&id1, NULL, stream1, &arg1);
  if (err_code1 != 0)
  {
    printf ("function error: %s\n", strerror(err_code1));
    return err_code1;
  }
  
  err_code2 = pthread_create(&id2, NULL, stream2, &arg2);
  if (err_code2 != 0)
  {
    printf ("function error: %s\n", strerror(err_code2));
    return err_code2;
  }
  
  printf ("Программа ждёт нажатия клавиши...\n");
  getchar();
  printf ("\nКлавиша нажата.\n");
  
  arg1.flag = 1;
  arg2.flag = 1;
  
  err_code1 = pthread_join(id1, (void**)&exit_code1);
  if (err_code1 != 0)
  {
    printf ("function error: %s\n", strerror(err_code1));
    return err_code1;
  }
  
  err_code2 = pthread_join(id2, (void**)&exit_code2);
  if (err_code2 != 0)
  {
    printf ("function error: %s\n", strerror(err_code2));
    return err_code2;
  }
  
  err_code1 = pthread_mutex_destroy(&mutex);
  if (err_code1 != 0)
  {
    printf ("function error: %s\n", strerror(err_code1));
    return err_code1;
  }
  
  printf ("Программа завершила работу.\n");
  return 0;
}
