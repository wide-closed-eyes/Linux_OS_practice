#!/bin/bash

gcc -c lab2_2.c
gcc -o lab2_2 lab2_2.o -pthread
./lab2_2
