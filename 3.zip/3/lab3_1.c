#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(void)
{
  printf("lab3_1.c started...\n");
  int status = 0;
  
  pid_t current = getpid();
  pid_t parent = getppid();
  
  printf("Current proccess ID = %d\n", current);
  printf("Parent proccess ID = %d\n", parent);
  
  char* argv[] = {"Pavel", "Dushkin","0362","earlier","0363", NULL};
  char* envp[] = {"any", "environment", NULL};
  
  pid_t pid = fork();
  printf("Daughter proccess ID = %d\n", pid);
  if (pid == -1)
    printf("Error!");
  else if (pid == 0)
  {  
    if (execve("./lab3_2", argv, envp) == -1)
      perror("Could not execve");
    sleep(1);
  }  
  else
  {
    while(waitpid(pid, &status, WNOHANG) == 0)
    {
      printf("Waiting...\n");
      usleep(500000);
    }
  } 
  
  if (WIFEXITED(status)!=0)
  {
    int exit_code = WEXITSTATUS(status);
    printf("lab3_1.c finished with code %d.\n", exit_code);  
  }
  return 0;
}

