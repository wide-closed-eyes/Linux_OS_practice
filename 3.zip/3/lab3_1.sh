#!/bin/bash

gcc -c lab3_1.c
gcc -o lab3_1 lab3_1.o
gcc -c lab3_2.c
gcc -o lab3_2 lab3_2.o
./lab3_1
