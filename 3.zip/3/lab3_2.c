#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[], char *envp[])
{
  printf("lab3_2.c start...\n");
  pid_t current = getpid();
  pid_t parent = getppid();
  
  printf("My process ID = %d\n", current);
  printf("My parents's process ID = %d\n", parent);
  
  int j = 0;
  while (envp[j]!= NULL)
  {
    printf("envp[%d] = %s\n", j++, envp[j]);
    sleep(1);
  }
  
  for (int i = 0; i<argc; i++)
  {
    printf("argv[%d] = %s\n", i, argv[i]);
    sleep(1);
  }
  
  printf("lab3_2.c finished.\n");
  exit(25); 
}
