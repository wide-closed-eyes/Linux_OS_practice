#include <stdio.h>

#include <sys/mman.h>
#include <sys/stat.h>        
#include <fcntl.h>           


#include <stdlib.h>
#include <unistd.h>

#include <string.h>
#include <pthread.h>
#include <semaphore.h>

#include <termios.h>

//просматриваем файл командой tail -f test.txt

//int threadstop = 0;
//sem_t *sem;
//int fd;
//FILE * fl;


int kbhit(void)
{
  struct termios oldt, newt;
  int ch;
  int oldf;
 
  tcgetattr(STDIN_FILENO, &oldt);
  newt = oldt;
  newt.c_lflag &= ~(ICANON | ECHO);
  tcsetattr(STDIN_FILENO, TCSANOW, &newt);
  oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
  fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
 
  ch = getchar();
 
  tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
  fcntl(STDIN_FILENO, F_SETFL, oldf);
 
  if(ch != EOF)
  {
    ungetc(ch, stdin);
    return 1;
  }
 
  return 0;
}




int main()
{
  printf("lab4_1 started...\n");
  printf("press any key to exit process\n");
  
  const char filename [20] = "lab4.txt";
  //const char SEM_name [20] = "/semaphor";
  sem_t *SEM = sem_open ("/sem", O_CREAT, 0644, 1);
  
  FILE *f;
  if ((f = fopen(filename, "a+")) != NULL)
    printf("File opened\n");
  else
  {
    printf("File can not be opened!");
    return -1;
  }
  int flag = 0;
  while (1)   
  {
     int ch  = kbhit();
     //printf("ch = %d\n", ch);
     if ((flag = sem_wait(SEM)) != 0) //set
     {
       printf("Semaphore locked error!");
       return -1;
     }
     
     for (int i = 0; i<10; i++)
     {
       fputc('1', f);
       printf("1");
       fflush(stdout);
       sleep(1);
       if (ch == 1)  
       break;
     }
     if ((flag = sem_post(SEM)) != 0) //free
     {
       printf("Semaphore unlocked error!");
       return -1;
     }
     
     if (ch == 1)  
       break;
     sleep(1);
  }
  //printf("key pressed: ch = %d\n", ch);
  printf("\nkey pressed\n");
  
  fclose(f);
  sem_close(SEM); //close
  sem_unlink("/sem"); //delete
  
  printf("lab4_1 finished.\n");
  return 0;
}
