#!/bin/bash

gcc -c lab4_1.c
gcc -o lab4_1 lab4_1.o
