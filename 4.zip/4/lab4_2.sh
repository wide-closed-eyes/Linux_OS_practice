#!/bin/bash

gcc -c lab4_2.c
gcc -o lab4_2 lab4_2.o
