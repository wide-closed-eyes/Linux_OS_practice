#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <fcntl.h>

pthread_mutex_t mutex;

typedef struct
{
  int flag;
  int flds;
  char *str;
} threads;

void *stream1(void * arg)
{ 
  //sleep(10);
  threads *args = (threads*) arg;
  printf("Поток 1 начал работу на запись...\n");
  sleep(1);
  while(args->flag == 0)
  {
    //pthread_mutex_lock(&mutex);
    if (write(args->flds, args->str, strlen(args->str)+1) != -1)
      printf("Поток 1 закончил запись\n");
    else
    {
      perror("Ошибка в записи данных");
      pthread_exit((void*)3);
    }
    //fflush(stdout);
    //pthread_mutex_unlock(&mutex);
    sleep(1);
  }
  printf ("Поток 1 закончил работу.\n");
  pthread_exit((void*)1);
}

void *stream2(void * arg)
{
  char const_str[100];
  threads *args = (threads*) arg;
  sleep(2);
  printf("Поток 2 начал работу на чтение...\n");
  sleep(1);
  while(args->flag == 0)
  {
    const_str[0] = 1;
    //pthread_mutex_lock(&mutex);
    if (read(args->flds, const_str, 100) != -1)
      printf("Поток 2 считал значение: %s\n", const_str);
    else
    {
      perror("Ошибка чтения данных");
      pthread_exit((void*)4);
    }
    //fflush(stdout);
    //pthread_mutex_unlock(&mutex);
    sleep(1);
  }
  printf ("Поток 2 закончил работу.\n");
  pthread_exit((void*)2);
}

int main()
{ 
  int filedes[2];
  char key;
  printf("Введине ключевое значение:\n1 - pipe с блокировкой\n2 - pipe2 без блокировки |Только для Linux|\n3 - pipe без блокировки\n");
  //scanf(" %c", &key);
  key = getchar();
  switch (key)
  {
  case '1':
  {
    if (pipe(filedes) == -1)
    {
    printf("ERROR");
    return -1;
    }
    break;
  }
  case '2':
  {
    if (pipe2(filedes, O_NONBLOCK) != 0)
    {
    perror("Ошибка в создании потока!");
    exit(EXIT_FAILURE);
    }
    break;
  }
  case '3':
  {
    if (pipe(filedes) == -1)
    {
    printf("ERROR");
    return -1;
    }
    fcntl(filedes[0], F_SETFL, O_NONBLOCK);
    fcntl(filedes[1], F_SETFL, O_NONBLOCK);
    break;
  }
  default:
  {
    printf("Введено некорректное ключевое значение\n");
    return -1;
  }
  }
  sleep(1);
  getchar();
  printf ("Программа начала работу...\n");
  pthread_t id1;
  pthread_t id2;
  
  int *exit_code1;
  int *exit_code2;
  
  threads arg1;
  arg1.flag = 0;
  arg1.str = get_current_dir_name();
  arg1.flds = filedes[1];
  
  threads arg2;
  arg2.flag = 0;
  arg2.str = NULL;
  arg2.flds = filedes[0];
  
  int err_code1, err_code2;
  
  err_code1 = pthread_mutex_init(&mutex, NULL);
  if (err_code1 != 0)
  {
    printf ("function error: %s\n", strerror(err_code1));
    return err_code1;
  }
  
  err_code1 =  pthread_create(&id1, NULL, stream1, &arg1);
  if (err_code1 != 0)
  {
    printf ("function error: %s\n", strerror(err_code1));
    return err_code1;
  }
  
  err_code2 = pthread_create(&id2, NULL, stream2, &arg2);
  if (err_code2 != 0)
  {
    printf ("function error: %s\n", strerror(err_code2));
    return err_code2;
  }
  
  printf ("Программа ждёт нажатия клавиши...\n");
  getchar();
  printf ("\nКлавиша нажата.\n");
  
  arg1.flag = 1;
  arg2.flag = 1;
  
  err_code1 = pthread_join(id1, (void**)&exit_code1);
  if (err_code1 != 0)
  {
    printf ("function error: %s\n", strerror(err_code1));
    return err_code1;
  }
  
  err_code2 = pthread_join(id2, (void**)&exit_code2);
  if (err_code2 != 0)
  {
    printf ("function error: %s\n", strerror(err_code2));
    return err_code2;
  }
  
  close(filedes[0]);
  close(filedes[1]);
  
  err_code1 = pthread_mutex_destroy(&mutex);
  if (err_code1 != 0)
  {
    printf ("function error: %s\n", strerror(err_code1));
    return err_code1;
  }
  
  printf ("Программа завершила работу.\n");
  return 0;
}
