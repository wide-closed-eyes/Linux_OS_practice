#!/bin/bash

gcc -c lab5_1.c
gcc -o lab5_1 lab5_1.o -pthread
./lab5_1
