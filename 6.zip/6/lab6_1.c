#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <semaphore.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/mman.h>
#include <sys/stat.h>  
#include <sys/types.h>
#include <linux/limits.h>

int kbhit(void)
{
  struct termios oldt, newt;
  int ch;
  int oldf;
 
  tcgetattr(STDIN_FILENO, &oldt);
  newt = oldt;
  newt.c_lflag &= ~(ICANON | ECHO);
  tcsetattr(STDIN_FILENO, TCSANOW, &newt);
  oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
  fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
 
  ch = getchar();
 
  tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
  fcntl(STDIN_FILENO, F_SETFL, oldf);
 
  if(ch != EOF)
  {
    ungetc(ch, stdin);
    return 1;
  }
 
  return 0;
}

typedef struct
{
  int key;
  char *path;
} data;

int main()
{
  printf("lab6_2 started...\n");
  printf("press any key to exit process\n");
  
  sem_t *SEM = sem_open ("/sem", O_CREAT, 0644, 0);
  sem_t *SEM_R = sem_open ("/sem_r", O_CREAT, 0644, NULL);
  int flag = 0;
  
  data arg;
  arg.key = 1;
  arg.path = get_current_dir_name();
  printf("Current path = %s\nSize arg = %ld\n", arg.path, sizeof(arg));
  
  int fd = shm_open("/my_mem", O_CREAT | O_RDWR, 0644);
  if (fd < 0)
  {
    perror("Ошибка создания участка разделяемой памяти!\n");
    return -1;
  }
  
  if (ftruncate(fd, PATH_MAX) != 0)
  {
    perror("Ошибка расширения разделяемой памяти!\n");
    close(fd);
    shm_unlink("/my_mem");
    return -1;
  }
  
  unsigned char* mem;
  mem = (unsigned char*)mmap(mem, PATH_MAX, PROT_WRITE | PROT_READ, MAP_SHARED, fd, 0);
  printf ("fghj\n");
  unsigned char *d;
  int val = 0;
  
  while (1)   
  {
     int ch  = kbhit();
     
     sem_getvalue(SEM, &val);
     printf("val = %d\n", val);
     
     d = get_current_dir_name();
     memcpy(mem, d, PATH_MAX);
     printf("Записал: %s\n", mem);
     printf("Запись осуществена\n");
     
     if ((flag = sem_post(SEM)) != 0) //free
     {
       printf("Semaphore unlocked error!");
       return -1;
     }
     
     if ((flag = sem_wait(SEM_R)) != 0) //set
     {
       printf("Semaphore locked error!");
       return -1;
     }
     if (ch == 1)  
       break;
     sleep(1);
  }
  printf("\nkey pressed\n");
  
  sem_close(SEM); //close
  sem_close(SEM_R);
  sem_unlink("/sem"); //delete
  sem_unlink("/sem_r");
  
  munmap(mem, PATH_MAX);
  close(fd);
  shm_unlink("/my_mem");
  
  printf("lab6_1 finished.\n");
  return 0;
}
















