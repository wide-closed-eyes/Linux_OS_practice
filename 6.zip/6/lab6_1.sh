#!/bin/bash

gcc -c lab6_1.c
gcc -o lab6_1 lab6_1.o
