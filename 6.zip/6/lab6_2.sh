#!/bin/bash

gcc -c lab6_2.c
gcc -o lab6_2 lab6_2.o
