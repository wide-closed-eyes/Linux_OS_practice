#!/bin/bash

gcc -c lab7_1.c
gcc -o lab7_1 lab7_1.o

./lab7_1

sudo setcap cap_sys_resource=eip lab7_1
./lab7_1
