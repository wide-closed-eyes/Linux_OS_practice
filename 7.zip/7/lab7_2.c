#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <semaphore.h>
#include <fcntl.h>
#include <termios.h>
#include <linux/limits.h>

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

int kbhit(void)
{
  struct termios oldt, newt;
  int ch;
  int oldf;
 
  tcgetattr(STDIN_FILENO, &oldt);
  newt = oldt;
  newt.c_lflag &= ~(ICANON | ECHO);
  tcsetattr(STDIN_FILENO, TCSANOW, &newt);
  oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
  fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
 
  ch = getchar();
 
  tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
  fcntl(STDIN_FILENO, F_SETFL, oldf);
 
  if(ch != EOF)
  {
    ungetc(ch, stdin);
    return 1;
  }
 
  return 0;
}

typedef struct
{
  long mtype;
  char buff[PATH_MAX];
} TMessage;

int main()
{
  printf("lab7_2 started...\n");
  key_t key;
  if ((key = ftok("lab7_2.c", 'A'))  == -1)
  {
    perror("Ошибка при генерации ключа очереди\n");
    return -1;
  }
  printf("Сгенерированный ключ = %d\n", key);

  int msgid;
  msgid = msgget(key, IPC_CREAT | 0666);
  if (msgget < 0)
  {
    msgget(key, 0);
    printf("Очередь открыта.\n");
  }
  else
    printf("Очередь создана\n");
  
  struct msqid_ds msqid_ds, *buf;
  buf = &msqid_ds;
  
  msgctl(msgid, IPC_STAT, buf);
  printf("\nРазмер очереди в байтах: %ld\n", buf->msg_qbytes);
  printf("Права на операции: %o\n\n", buf->msg_perm.mode);
  
  TMessage message;
  message.mtype = 1;
  memset(message.buff, 0, sizeof(message.buff));
  int result = 0;
  
  while (1)
  {
    int ch = kbhit();
    if ((result = msgrcv(msgid, &message, sizeof(message.buff), message.mtype, IPC_NOWAIT)) == -1)
    {
      perror("Ошибка получения сообщения!\n");
      msgctl(msgid, IPC_RMID, NULL);
      return -1;
    }
    printf("Полученное сообщение: %s\n", message.buff);
    sleep(1);
    if (ch == 1)
      break;
  }
  printf("Клавиша нажата\n");
  
  if (msgctl(msgid, IPC_RMID, NULL) == -1)
  {
    perror("Ошибка удаления очереди\n");
    return -1;
  }
  printf("Очереди удалена\n");
  printf("lab7_2 finished\n");
  return 0;
}
