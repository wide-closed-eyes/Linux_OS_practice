#!/bin/bash

gcc -c lab7_2.c
gcc -o lab7_2 lab7_2.o
