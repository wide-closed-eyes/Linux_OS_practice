#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <pthread.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>

pthread_mutex_t mutex;

typedef struct
{
  int flag;
  int number;
  char *str;
} threads;

int s, s1;
struct sockaddr_in address;
struct sockaddr_in address_from;
socklen_t Length;


void *transmission_request( void *arg)
{
sleep(1);
  threads *args = (threads*) arg;
  printf("Поток передачи запросов начал работу...\n");
  int bytes = 0;
  
  while(args->flag == 0)
  {
    sprintf(args->str, "%d", args->number);
    printf("Message = %s\n", args->str);
    //pthread_mutex_lock(&mutex);
    
    char buf[15];
    //itoa(1, buf, 10);
    sprintf(buf, "%d", args->number);
    bytes = sendto(s, buf, 8, 0, (struct sockaddr*)&address, sizeof(address));
    if ( bytes != sizeof(args->str) )
    {
      printf("Ошибка в отправке пакетов\nReturn value = %d\nExpected value = %ld\n\n", bytes, sizeof(args->str) );
      exit(-1);
    }
    //pthread_mutex_unlock(&mutex);
    printf("Запрос №%d передан: %s.\n", args->number, args->str);
    args->number += 1;
    sleep(1);
  }
  
  printf("Поток передачи запросов закончил работу.\n");
  pthread_exit((void*)1);
}

void *receiving_request(void *arg)
{
  //sleep(1);
  threads *args = (threads*) arg;
  printf("Поток получения ответов начал работу\n");
  int bytes = 0;
  socklen_t Length = sizeof(address_from);
  
  while(args->flag == 0)
  {
    //if (queue_flag != 1)
      //continue;
    //pthread_mutex_lock(&mutex);
    bytes = recvfrom( s1, args->str, sizeof(args->str), 0, (struct sockaddr*)&address_from, &Length);
    if (bytes <= 0)
    {
      printf("Жду ответа от сервера...\n");
      //pthread_mutex_unlock(&mutex);
      sleep(1);
      continue;
    }
    //pthread_mutex_unlock(&mutex);
    printf("bytes = %d\n", bytes);
    printf("Ответ №%d получен: %s.\n", args->number, args->str);
    args->number += 1;
    //queue_flag = 0;
    sleep(1);
  }
  
  printf("Поток получения ответов закончил работу.\n");
  pthread_exit((void*)2);
}

int main()
{
  printf("client lab8_1 started...\n");
  
  pthread_t str1;
  pthread_t str2;
  
  int *exit_code1;
  int *exit_code2;
  
  threads arg1;
  arg1.flag = 0;
  arg1.number = 1;
  arg1.str = get_current_dir_name();
  
  threads arg2;
  arg2.flag = 0;
  arg2.number = 1;
  arg2.str = get_current_dir_name();
  
  int err_code = 0;
  if (pthread_mutex_init(&mutex, NULL) != 0)
  {
    perror("mutex init ERROR!\n");
    exit (1);
  }
  
  if ((s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
  {
    perror("client socket EROOR!\n");
    exit (1);
  }
  printf("Сокет передачи сообщений успешно открыт.\n");
  if ((s1 = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
  {
    perror("client socket EROOR!\n");
    exit (1);
  }
  
  address.sin_family = AF_INET;
  address.sin_addr.s_addr = inet_addr("127.0.0.1"); 
  uint32_t port = 1666;
  address.sin_port = htons((unsigned short) port);
  
  address_from.sin_family = AF_INET;
  address_from.sin_addr.s_addr = inet_addr("127.0.0.1"); 
  uint32_t portfrom = 4555;
  address_from.sin_port = htons((unsigned short) portfrom);
  
  
  if (bind(s1, (const struct sockaddr *) &address_from, sizeof( struct sockaddr)) < 0)
  {
    printf("Ошибка привязки сокета к адресу\n");
  }
  /*if ( fcntl( s, F_SETFL, O_NONBLOCK, 1 ) == -1 )
  {
    printf("Ошибка перевода сокета в неблокирующее состояние\n");
    exit(-1);
  }
  if ( fcntl( s1, F_SETFL, O_NONBLOCK, 1 ) == -1 )
  {
    printf("Ошибка перевода сокета в неблокирующее состояние\n");
    exit(-1);
  }*/
  
  err_code =  pthread_create(&str1, NULL, transmission_request, &arg1);
  if (err_code != 0)
  {
    printf ("function error: %s\n", strerror(err_code));
    return err_code;
  }
  
  err_code =  pthread_create(&str2, NULL, receiving_request, &arg2);
  if (err_code != 0)
  {
    printf ("function error: %s\n", strerror(err_code));
    return err_code;
  }
  
  printf ("Программа ждёт нажатия клавиши...\n");
  getchar();
  printf ("\nКлавиша нажата.\n");
  
  arg1.flag = 1;
  arg2.flag = 1;
  
  err_code = pthread_join(str1, (void**)&exit_code1);
  if (err_code != 0)
  {
    printf ("function error: %s\n", strerror(err_code));
    return err_code;
  }
  
  err_code = pthread_join(str2, (void**)&exit_code2);
  if (err_code != 0)
  {
    printf ("function error: %s\n", strerror(err_code));
    return err_code;
  }
  
  if (pthread_mutex_destroy(&mutex) != 0)
  {
    perror("mutex destroy ERROR!\n");
    exit (1);
  }
  
  if (close(s) != 0)
  {
    perror("socket closing ERROR!\n");
    exit (1);
  }
  if (close(s1) != 0)
  {
    perror("socket closing ERROR!\n");
    exit (1);
  }
  printf("Сокет передачи сообщений закрыт.\n");
  
  printf("client lab8_1 finished.\n");
  return 0;
}
