#!/bin/bash

gcc -c lab8_1.c
gcc -o lab8_1 lab8_1.o
