#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <pthread.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "queue.h"

typedef struct
{
  int flag;
  int number;
  char *str;
} threads;

struct queue *q; //указатель на очередь
pthread_mutex_t mutex;
//int queue_flag = 0;
int s, s1;
struct sockaddr_in address;
struct sockaddr_in address_from;
char buf[256];


void *get_request( void *arg)
{
  threads *args = (threads*) arg;
  printf("Поток получения запросов начал работу...\n");
  int received_bytes = 0;  
  int num;
  while(args->flag == 0)
  {
    pthread_mutex_lock(&mutex);
    if (*q->count >= *q->max)
    {
    	pthread_mutex_unlock(&mutex);
    	printf("Очередь переполнена\n");
    	sleep(1);
    	continue;
    }
    socklen_t Length = sizeof(address);
    received_bytes = recvfrom( s, buf, 256, 0, (struct sockaddr*)&address, &Length);
    
    if (received_bytes <= 0)
    {
        pthread_mutex_unlock(&mutex);
        printf("Нет сообщений\n");
    	sleep(1);
    	continue;
    }
    
    num = atoi(buf);
    queue_add (q, num, 0); // добавление запроса в очередь
    pthread_mutex_unlock(&mutex);
    printf("Принят запрос№: %s\n", buf);
    args->number += 1;
    sleep(1);
  }
  
  printf("Поток получения запросов закончил работу.\n");
  pthread_exit((void*)1);
}

void *send_request(void *arg)
{
  threads *args = (threads*) arg;
  printf("Поток отправления ответов начал работу\n");
  int bytes = 0;
  sleep(1);
  while(args->flag == 0)
  {
    pthread_mutex_lock(&mutex);
    if (*q->count == 0)
    {
      pthread_mutex_unlock(&mutex);
      printf("Очередь пустая\n");
      sleep(1);
      continue;
    }
    uint8_t d;
    int ret = queue_get (q, &d);
    
    args->str = get_current_dir_name();
    bytes = sendto(s, args->str, sizeof(args->str), 0, (struct sockaddr*)&address_from, sizeof(address_from));
    pthread_mutex_unlock(&mutex);
    printf("ОТВЕТ: %s\nбАЙТ = %d\n", args->str, bytes);
    if ( bytes != sizeof(args->str) )
    {
      printf("Ошибка в отправке пакетов\nReturn value = %d\nExpected value = %ld\n\n", bytes, sizeof(args->str) );
      exit(-1);
    }
    sleep(1);
  }
  
  printf("Поток отправления ответов закончил работу.\n");
  pthread_exit((void*)2);
}

int main()
{
  q = init (20, 1); // инийиализация очереди
  
  printf("server lab8_2 started...\n");
  
  pthread_t str1;
  pthread_t str2;
  
  int *exit_code1;
  int *exit_code2;
  
  threads arg1;
  arg1.flag = 0;
  arg1.number = 1;
  
  threads arg2;
  arg2.flag = 0;
  arg2.number = 1;
  
  int err_code = 0;
  if (pthread_mutex_init(&mutex, NULL) != 0)
  {
    perror("mutex init ERROR!\n");
    exit (1);
  }
  
  if ((s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
  {
    perror("client socket EROOR!\n");
    exit (1);
  }
  if ((s1 = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
  {
    perror("client socket EROOR!\n");
    exit (1);
  }
  printf("Сокет передачи сообщений успешно открыт.\n");
  
  address.sin_family = AF_INET;
  address.sin_addr.s_addr = inet_addr("0"); 
  uint32_t port = 1666;
  address.sin_port = htons((unsigned short) port);
  
  address_from.sin_family = AF_INET;
  address_from.sin_addr.s_addr = inet_addr("0"); 
  uint32_t portfrom = 4555;
  address_from.sin_port = htons((unsigned short) portfrom);
  
  if (bind(s, (struct sockaddr *) &address, sizeof(address)) < 0)
  {
    printf("Ошибка привязки сокета к адресу\n");
    //exit (-1);
  }
  if ( fcntl( s, F_SETFL, O_NONBLOCK, 1 ) == -1 )
  {
    printf("Ошибка перевода сокета в неблокирующее состояние\n");
    exit(-1);
  }
  if ( fcntl( s1, F_SETFL, O_NONBLOCK, 1 ) == -1 )
  {
    printf("Ошибка перевода сокета в неблокирующее состояние\n");
    exit(-1);
  }
  
  
  err_code =  pthread_create(&str1, NULL, get_request, &arg1);
  if (err_code != 0)
  {
    printf ("function error: %s\n", strerror(err_code));
    return err_code;
  }
  
  err_code =  pthread_create(&str2, NULL, send_request, &arg2);
  if (err_code != 0)
  {
    printf ("function error: %s\n", strerror(err_code));
    return err_code;
  }
  
  printf ("Программа ждёт нажатия клавиши...\n");
  getchar();
  printf ("\nКлавиша нажата.\n");
  
  arg1.flag = 1;
  arg2.flag = 1;
  
  err_code = pthread_join(str1, (void**)&exit_code1);
  if (err_code != 0)
  {
    printf ("function error: %s\n", strerror(err_code));
    return err_code;
  }
  
  err_code = pthread_join(str2, (void**)&exit_code2);
  if (err_code != 0)
  {
    printf ("function error: %s\n", strerror(err_code));
    return err_code;
  }
  
  if (pthread_mutex_destroy(&mutex) != 0)
  {
    perror("mutex destroy ERROR!\n");
    exit (1);
  }
  
  if (close(s) != 0)
  {
    perror("socket closing ERROR!\n");
    exit (1);
  }
  if (close(s1) != 0)
  {
    perror("socket closing ERROR!\n");
    exit (1);
  }
  printf("Сокет передачи сообщений закрыт.\n");
  
  printf("server lab8_2 finished.\n");
  return 0;
}
