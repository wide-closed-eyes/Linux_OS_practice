#!/bin/bash

gcc -c lab8_2.c
gcc -o lab8_2 lab8_2.o
