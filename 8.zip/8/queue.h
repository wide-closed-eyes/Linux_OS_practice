#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

struct queue {
	uint8_t **data;
	int *low;
	int *high;
	int *count;
	int *max;
	int max_prio;
	int min_prio;
};

struct queue *init (size_t size, int size_prio)
{
	struct queue * q = calloc (1, sizeof (struct queue));
	q->max_prio = size_prio;

	q->data = calloc (size_prio, sizeof (void *));
	q->low = calloc (size, sizeof (int));
	q->high = calloc (size, sizeof (int));
	q->max = calloc (size, sizeof (int));
	q->count = calloc (size, sizeof (int));

	for (int i = 0; i < size_prio; i++) {
		q->data[i] = calloc (size, sizeof (uint8_t));
		q->low[i] = q->high[i] = size - 1;
		q->max[i] = size;
	}

	return q;
}

int queue_add (struct queue *q, uint8_t a, int prio)
{

	if (q->min_prio > prio) q->min_prio = prio;

	if (q->count[prio] == q->max[prio]) {
		fprintf (stderr, "not enough queue size\n");
		return -1;
	}

	q->data[prio][q->low[prio]--] = a;
	q->count[prio]++;

	if (q->low[prio] < 0) {
		q->low[prio] = q->max[prio] - 1;
	}

	return 0;
}

int queue_get (struct queue *q, uint8_t *val)
{
	uint8_t a = 0;
	for (int i = q->min_prio; i < q->max_prio; i++) {
		if (q->count[i] > 0) {
			a = q->data[i][q->high[i]--];
			q->count[i]--;

			if (q->high[i] < 0) {
				q->high[i] = q->max[i] - 1;
			}

			q->min_prio = i;

			*val = a;
			return 0;
		}
	}

	printf ("queue is empty\n");
	return -1;
}
