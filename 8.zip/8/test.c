#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

int main()
{
  printf("test started...\n");
  
  struct queue *q;
  q = init (10, 1);
  //uint8_t d;
  for (int i = 0; i<7; i++)
  	queue_add (q, i, 0);
  uint8_t d;
  int count = *q->count;
  for (int j = 0; j<count; j++)
  {
    queue_get (q, &d);
    printf("get value = %d\n", d);
  }
  
  printf("test finished.\n");
  return 0;
}
