#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>

#include <sched.h> //для clone
#include <sys/types.h> //для 
#include <unistd.h>   // getpid
#include <sys/wait.h> //для waitpid

#define STACK_SIZE (1024 * 1024)

static int funcPID(void *arg)
{
  sleep(1);
  printf ("Дочерний процесс запущен\n");
  pid_t child_pid = getpid();
  printf("child PID = %d\n", child_pid);
  child_pid = getppid();
  printf("child's parent PID = %d\n", child_pid);
  printf ("Дочерний процесс закончен\n\n");
  
  return 0;
}

int main(int argc, char *argv[])
{
  printf("lab9 started...\n");
  
  char *stack;
  char *stackTop;
  stack = (char*) malloc(STACK_SIZE);
  stackTop = stack+STACK_SIZE;
  
  pid_t current_pid;
  int childPID;
  
  current_pid = getpid();
  printf("main PID = %d\n", current_pid);
  current_pid = getppid();
  printf("main's parent PID = %d\n", current_pid);
  
  childPID = clone(funcPID, stackTop, SIGCHLD, argv[1]);
  if (childPID == -1)
  {
    perror("Ошибка при создании дочернего процесса\n");
    exit(-1);
    
  }
  printf("\nДочерний процесс открыт в том же адресном пространстве PID\n");
  sleep(2);
  
  waitpid(childPID, NULL, 0);
  
  childPID = clone(funcPID, stackTop, CLONE_NEWPID|SIGCHLD, argv[1]);
  if (childPID == -1)
  {
    perror("Ошибка при создании дочернего процесса\n");
    exit(-1);
    
  }
  printf("Дочерний процесс открыт в собственном адресном пространстве PID\n");
  sleep(2);
  
  waitpid(childPID, NULL, 0);
  
  
  
  printf("lab9 finished.\n");
  return 0;
}
