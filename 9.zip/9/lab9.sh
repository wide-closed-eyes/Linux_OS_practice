#!/bin/bash

gcc -c lab9.c
gcc -o lab9 lab9.o

sudo setcap cap_sys_admin=ep lab9
./lab9
